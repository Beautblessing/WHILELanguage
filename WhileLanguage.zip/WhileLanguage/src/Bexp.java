
public abstract class Bexp {
	
	abstract boolean eval(State st);
	Bexp(){
		
	}
	
	

	
}
