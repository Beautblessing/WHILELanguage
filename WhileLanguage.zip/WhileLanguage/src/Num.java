
public class Num extends Aexp{
	
     int n;
	
	Num(int n) {
		this.n = n;
	}
	
	int eval(State st){
		return n;
	} 
	
}
	


