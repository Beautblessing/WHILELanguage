import java.util.Hashtable;

public abstract class Aexp {
	
	abstract int eval (State st);
	
	
	
		
	Aexp(){
			
		}
		
	
	
	
	public static void main(String[] args )
    {
    	    
			
		// Test Cases:
		
		// Test case I           // Var, Assign, While , greater , Sub , Semicolon, State
		/*  Var z 
		 *  assign z = 10
		 *  print original z
		 *  while (z > 3)
		 *    {
		 *      assign z = z-1
		 *      ;
		 *    }  
		 *    
		 *  print result z
		 * 
		 */
		
			
			
		    
		    Var z = new Var('z');
		    Cexp asgnZ = new Assign(z, new Num(10));
		    State original = asgnZ.eval(new State());
		    System.out.println(z.eval(original));
		    Cexp whileLoop = new While(new greater(z,new Num(3)),new Assign(z,new Sub(z,new Num(1))));
		    Cexp semicolon = new Semicolon(asgnZ, whileLoop);
		    State result = semicolon.eval(new State());
		    System.out.println(z.eval(result));
		    
		    
		 
		 
		 //Test case II       //Var, Assign, Ifelse, less, equals, skip() 
		    
		    
		   /* var x
		    * assign x = 4
		    * if (6<4) ? skip() : assign x = 6
		    * print x
		    * 
		    * if (x == 6) ? skip() : assign x = 10
		    * print x
		    */
		 
		Var x = new Var('x');
		State x_state0 = new Assign(x, new Num(4)).eval(new State());
		
		State x_state1 = new Ifelse(new less (new Num(6),x),new Skip(), new Assign(x,new Num(6))).eval(x_state0);
		
		System.out.println(x.eval(x_state1));
		
		State x_state2 = new Ifelse(new equals (new Num(6),x),new Skip(), new Assign(x,new Num(10))).eval(x_state1);
		
		System.out.println(x.eval(x_state2));
		
		
		// Test case III  // Boolean functions
		
		System.out.println(new Or (new True(), new False()).eval(new State()));
		System.out.println(new Or (new False(), new False()).eval(new State()));	
		
		System.out.println(new And (new True(), new False()).eval(new State()));
		System.out.println(new And (new True(), new Not(new False())).eval(new State()));
		
    }
    	    

}
