
public class Skip extends Cexp{
	

	
	State eval(State st){
		return st;
	}

}
