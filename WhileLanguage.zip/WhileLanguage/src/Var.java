

public class Var extends Aexp{
	
	Character c;
	
	Var(Character c){
		this.c = c;
	}

   
	
	int eval(State st){
		return st.readstate(this);
	} 
}
