import java.util.Hashtable;
public class State {
	
	Hashtable<Var,Integer> StateHashTable = new Hashtable<Var,Integer>();
	
	void assignstate(Var v, Integer n){
	
		StateHashTable.put(v, n);
		
	}
	
	Integer readstate(Var v)
	{
		return StateHashTable.get(v);
	}

}
