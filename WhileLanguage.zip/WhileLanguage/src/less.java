
public class less extends Bexp {
	Aexp left;
	Aexp right;
	
	less(Aexp left, Aexp right){
		this.left = left;
		this.right = right;
	}
	
	boolean eval(State st)
	{
		/*if (left.eval(st) < right.eval(st))
		{
			return true;
		}
		
		else 
			return false; */
		
		return (left.eval(st) < right.eval(st));
	}

}
