
public class Sub extends Aexp{
	
	Aexp left;// = new Aexp();
	Aexp right ; //= new Aexp();
	
	
	Sub(Aexp left, Aexp right) {
		this.left = left;
		this.right = right;
	}

	
int eval(State st){
		return left.eval(st)-right.eval(st);
	} 

}
