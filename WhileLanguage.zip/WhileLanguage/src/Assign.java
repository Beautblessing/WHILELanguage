
public class Assign extends Cexp{

Var v;
Aexp e;

Assign (Var v, Aexp e){
	this.v = v;
	this.e = e;
}

State eval (State st)
{
	int n = e.eval(st);
	st.assignstate(v, n);
	return st;
}

}
