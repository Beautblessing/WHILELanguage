
public class While extends Cexp{

	Bexp b;
	Cexp c;
	
	While(Bexp b, Cexp c)
	{
		this.b = b;
		this.c = c;
	
	}
	
	State eval(State st)
	{
		boolean b1 = b.eval(st);
		
		if(!b1)
		{
		return st;
	    }
		
		else  // if(b1)
		{
			State st1 = c.eval(st);
			While w = new While(b,c);
			State st2 = w.eval(st1);
			return st2;
			
		}
	}
	
	
}
