
public class Ifelse extends Cexp{
	
	Bexp b;
	Cexp c1;
	Cexp c2;
	
	Ifelse(Bexp b, Cexp c1, Cexp c2)
	{
		this.b = b;
		this.c1 = c1;
		this.c2 = c2;
	}
	
	State eval(State st)
	{
		boolean b1 = b.eval(st);
		
		if(b1 == true)
		{
		State st1 = c1.eval(st);
		return st1;
		}
		
		else
		{
			State st1 = c2.eval(st);
			return st1;
		}
		
	}
	
	

}
