
public class Semicolon extends Cexp {
	
	Cexp c1;
	Cexp c2;
	
	Semicolon (Cexp c1, Cexp c2)
	{
		this.c1 = c1;
		this.c2 = c2;
	}
	
	State eval(State st)
	{
		State st1 = c1.eval(st);
		State st2 = c2.eval(st1);
		return (st2);
		
	}

}
